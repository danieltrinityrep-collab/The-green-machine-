
# The Green Machine (Next.js Release)

## Local dev
```bash
npm install
npm run dev
# open http://localhost:3000
```

## Deploy to Vercel
1. Push this folder to GitHub
2. Import into Vercel
3. Deploy (free)

### Config
- Update config at top of `components/App.jsx` if needed.
- Fixed sample bill images live at `/public/bills/bill1.jpg` ... `/bill4.jpg`.
