
export default function Privacy() {
  return (
    <main className="max-w-3xl mx-auto px-4 py-10 text-green-900">
      <h1 className="text-2xl font-bold text-green-800">Privacy Policy</h1>
      <p className="text-xs text-green-700 mt-1">Last updated: 2025-10-20</p>

      <section className="mt-6 space-y-3 text-sm">
        <p>
          The Green Machine (“we”, “us”) collects only the information needed to provide solar assessments,
          answer questions, and schedule consultations. We respect your privacy and keep data minimal.
        </p>

        <h2 className="font-semibold text-green-800 mt-4">Information We Collect</h2>
        <ul className="list-disc pl-5 space-y-1">
          <li>Contact details: name, email, phone</li>
          <li>Service details: address, utility (e.g., Eversource/UI)</li>
          <li>Message content you send via our forms</li>
        </ul>

        <h2 className="font-semibold text-green-800 mt-4">How We Use Your Information</h2>
        <ul className="list-disc pl-5 space-y-1">
          <li>To respond to requests and schedule consultations</li>
          <li>To prepare high-level estimates and next steps</li>
          <li>To improve our site and services</li>
        </ul>

        <h2 className="font-semibold text-green-800 mt-4">Data Sharing</h2>
        <p>We do not sell your data. We use Formspree to process form submissions and standard hosting/analytics (e.g., Vercel) to run the site. These providers may process limited data on our behalf.</p>

        <h2 className="font-semibold text-green-800 mt-4">Data Security & Retention</h2>
        <p>We keep information only as long as needed to provide services or comply with law. While no method is 100% secure, we use reasonable safeguards and limit what we store.</p>

        <h2 className="font-semibold text-green-800 mt-4">Your Choices</h2>
        <ul className="list-disc pl-5 space-y-1">
          <li>You may request access, correction, or deletion of your information.</li>
          <li>You can opt out of further contact at any time.</li>
        </ul>

        <h2 className="font-semibold text-green-800 mt-4">Children’s Privacy</h2>
        <p>Our services are intended for adults and household decision-makers. We do not knowingly collect personal information from children.</p>

        <h2 className="font-semibold text-green-800 mt-4">Contact</h2>
        <p>Questions or requests? Call <a className="underline" href="tel:+12035037385">+1 203-503-7385</a> or use the “Request by Email” form in the app.</p>
      </section>
    </main>
  );
}
