
export default function Terms() {
  return (
    <main className="max-w-3xl mx-auto px-4 py-10 text-green-900">
      <h1 className="text-2xl font-bold text-green-800">Terms of Use</h1>
      <p className="text-xs text-green-700 mt-1">Last updated: 2025-10-20</p>

      <section className="mt-6 space-y-3 text-sm">
        <p>Welcome to The Green Machine. By using this site/app, you agree to these terms.</p>

        <h2 className="font-semibold text-green-800 mt-4">1. Educational Content & Estimates</h2>
        <p>
          The information and savings estimates provided are for educational purposes only. Actual results vary by roof
          condition, shading, utility rates, program eligibility, and financing terms. Nothing here is a binding offer or guarantee.
        </p>

        <h2 className="font-semibold text-green-800 mt-4">2. No Professional Advice</h2>
        <p>
          Content is general in nature and not legal, financial, or technical advice. You should consult appropriate professionals before making decisions.
        </p>

        <h2 className="font-semibold text-green-800 mt-4">3. User Conduct</h2>
        <p>You agree not to misuse the site, attempt unauthorized access, or submit unlawful content.</p>

        <h2 className="font-semibold text-green-800 mt-4">4. Third‑Party Services</h2>
        <p>
          We use Formspree for form delivery and may link to official state resources (e.g., PURA/DEEP/EnergizeCT). We are not responsible
          for third‑party sites or changes to their content.
        </p>

        <h2 className="font-semibold text-green-800 mt-4">5. Limitation of Liability</h2>
        <p>
          The Green Machine is provided “as is.” To the fullest extent permitted by law, we disclaim warranties and limit liability for any indirect or consequential damages.
        </p>

        <h2 className="font-semibold text-green-800 mt-4">6. Changes</h2>
        <p>We may update these terms or our services. Continued use after changes means you accept the updated terms.</p>

        <h2 className="font-semibold text-green-800 mt-4">7. Contact</h2>
        <p>Questions about these terms? Call <a className="underline" href="tel:+12035037385">+1 203-503-7385</a> or use the “Request by Email” form.</p>
      </section>
    </main>
  );
}
