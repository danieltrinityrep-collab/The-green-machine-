
import React, { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Users, Leaf, Wallet, Calendar, MapPin, Share2, Upload, LineChart, Info, Building2, Phone, Newspaper, ShieldCheck, Scale, FileText, X, Clock } from "lucide-react";

// ========= CONFIG
const CONFIG = {
  CONTACT_PHONE: "+12035037385",
  LEAD_WEBHOOK_URL: "https://formspree.io/f/mdkwjyrn",
  SOURCES: {
    PURA_RPS: "https://portal.ct.gov/pura/rps/renewable-portfolio-standards-overview",
    PURA_FAQ_PDF: "https://portal.ct.gov/-/media/pura/1---website-media/faqs---august-2024.pdf",
    OCC_PUBLIC_BENEFITS: "https://portal.ct.gov/occ/electricity/electricity/electricity",
    ENERGIZE_DASHBOARD: "https://www.energizect.com/eeb-statewide-energy-efficiency-dashboard",
    UI_SAMPLE_BILL: "https://www.uinet.com/account/understandyourbill/samplebill"
  }
};

// ========= UI PRIMITIVES
const Card = ({ className = "", children }) => (
  <div className={`bg-white/90 backdrop-blur rounded-2xl shadow-md border border-green-200 ${className}`}>{children}</div>
);
const CardHeader = ({ children }) => (
  <div className="p-4 border-b border-green-100 flex items-center gap-2">{children}</div>
);
const CardContent = ({ children }) => <div className="p-4">{children}</div>;
const Button = ({ className = "", children, ...props }) => (
  <button className={`px-4 py-2 rounded-2xl shadow-sm border border-green-400 hover:shadow transition active:translate-y-px ${className}`} {...props}>{children}</button>
);
const Input = ({ className = "", ...props }) => (
  <input className={`w-full px-3 py-2 rounded-xl border border-green-300 focus:outline-none focus:ring focus:ring-green-200 ${className}`} {...props} />
);
const Label = ({ className = "", children }) => (
  <label className={`text-sm font-medium text-green-900 ${className}`}>{children}</label>
);

// ========= HELPERS
const currency = (n) => n.toLocaleString(undefined, { style: "currency", currency: "USD" });

// ========= DATA
const demoEvents = [
  { id: 1, title: "Neighborhood Solar Q&A Night", date: "2025-10-23", time: "6:30 PM", where: "New Haven Public Library", desc: "Bring your bill and learn how to decode it—fast and simple." },
  { id: 2, title: "Rooftop Readiness Workshop", date: "2025-11-02", time: "1:00 PM", where: "Hamden Community Center", desc: "Roof age, shading, and solar basics with hands-on demos." },
];
const demoNews = [
  { id: 1, headline: "CT utilities announce winter rate updates", source: "The Green Machine", time: "2h ago" },
  { id: 2, headline: "Solar + battery adoption rising across New England", source: "Energy Wire", time: "Yesterday" },
];
const demoLeaders = [
  { name: "River Street", points: 840 },
  { name: "Whitney Ave", points: 610 },
  { name: "Prospect St", points: 520 },
];

// ========= MODAL
function Modal({ open, onClose, title, children }){
  if(!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/30" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl border border-green-300 max-w-2xl w-full">
        <div className="p-4 border-b border-green-100 flex items-center justify-between">
          <div className="flex items-center gap-2 text-green-800 font-semibold"><Info className="w-5 h-5"/>{title}</div>
          <button onClick={onClose} className="p-1 rounded-xl border border-green-200 text-green-700"><X className="w-4 h-4"/></button>
        </div>
        <div className="p-4 text-green-900 text-sm">{children}</div>
      </div>
    </div>
  );
}

// ========= SIMPLE LOGO
function LogoMark(){
  return (
    <svg width="28" height="28" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" className="shrink-0">
      <circle cx="32" cy="32" r="30" fill="#22c55e" stroke="#eab308" strokeWidth="4"/>
      <text x="18" y="40" fontFamily="Inter, system-ui, sans-serif" fontWeight="800" fontSize="22" fill="#fff">GM</text>
      <path d="M42 20 34 44" stroke="#fff" strokeWidth="4"/> 
    </svg>
  );
}

// ========= Annotated bills (fixed images + labels)
function AnnotatedBill({ title, template, defaultSrcs = [] }){
  const [img, setImg] = useState(defaultSrcs[0] || null);
  const [showLabels, setShowLabels] = useState(true);
  const [showRedaction, setShowRedaction] = useState(true);
  const [selectedIdx, setSelectedIdx] = useState(0);

  const templates = {
    ui: {
      highlights: [
        { label: "Public Benefits", left: 68, top: 15, width: 26, height: 6, color: "bg-green-300/50 border-green-600" },
        { label: "Transmission", left: 36, top: 15, width: 26, height: 6, color: "bg-blue-300/40 border-blue-600" },
        { label: "Local Delivery", left: 52, top: 15, width: 26, height: 6, color: "bg-purple-300/40 border-purple-600" },
      ],
      redact: [
        { left: 74, top: 3, width: 20, height: 4 },
        { left: 4, top: 4, width: 45, height: 8 },
      ]
    },
    eversource: {
      highlights: [
        { label: "Comb. Public Benefit Chrg", left: 8, top: 78, width: 40, height: 5, color: "bg-green-300/50 border-green-700" },
        { label: "FMCC Delivery Chrg", left: 8, top: 72.5, width: 40, height: 5, color: "bg-orange-300/50 border-orange-700" },
        { label: "Transmission Chrg", left: 8, top: 60.5, width: 40, height: 5, color: "bg-blue-300/40 border-blue-700" },
      ],
      redact: [
        { left: 68, top: 3, width: 26, height: 5 },
        { left: 8, top: 9, width: 50, height: 8 },
      ]
    }
  };

  const t = templates[template];

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="font-semibold text-green-800">{title} <span className="text-xs text-green-700">(Sample)</span></div>
        <div className="flex items-center gap-2 text-xs">
          {defaultSrcs.length > 1 && (
            <select
              className="px-2 py-1 rounded-lg border border-green-300 bg-white"
              value={selectedIdx}
              onChange={(e)=>{ const idx = Number(e.target.value); setSelectedIdx(idx); setImg(defaultSrcs[idx]); }}
            >
              {defaultSrcs.map((s, i) => <option key={i} value={i}>Image {i+1}</option>)}
            </select>
          )}
          <label className="flex items-center gap-1"><input type="checkbox" checked={showLabels} onChange={e=>setShowLabels(e.target.checked)}/> Labels</label>
          <label className="flex items-center gap-1"><input type="checkbox" checked={showRedaction} onChange={e=>setShowRedaction(e.target.checked)}/> Redaction</label>
        </div>
      </div>
      <div className="p-2 border border-green-200 rounded-xl">
        <div className="relative mt-1">
          {img ? (
            <div className="relative">
              <img src={img} alt={`${title} bill`} className="w-full rounded-xl border border-green-200"/>
              {showLabels && t.highlights.map((h,i)=> (
                <div key={i} className={`absolute ${h.color} border rounded-md text-[10px] px-1 py-0.5`} style={{left:`${h.left}%`, top:`${h.top}%`, width:`${h.width}%`, height:`${h.height}%`, display:'flex', alignItems:'center'}}>
                  <span className="drop-shadow-[0_1px_0_rgba(255,255,255,0.6)] text-green-900">{h.label}</span>
                </div>
              ))}
              {showRedaction && t.redact.map((r,i)=> (
                <div key={`r${i}`} className="absolute bg-black/80 rounded-sm" style={{left:`${r.left}%`, top:`${r.top}%`, width:`${r.width}%`, height:`${r.height}%`}}/>
              ))}
            </div>
          ) : (
            <div className="h-40 bg-green-50 border border-green-100 rounded-xl flex items-center justify-center text-xs text-green-700">No image provided.</div>
          )}
        </div>
      </div>
      <div className="text-xs text-green-700">These images are bundled in the app. Redaction overlays run on-device.</div>
    </div>
  );
}

// ========= CT Mandate
function CTMandate(){
  const [open,setOpen]=useState(false);
  const [showBills,setShowBills]=useState(false);
  return (
    <Card className="border-green-700/40">
      <CardHeader>
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-full bg-green-100 border border-green-200">
            <ShieldCheck className="w-5 h-5 text-green-700"/>
          </div>
          <h3 className="font-semibold text-green-800">Connecticut Energy Mandates & Public Benefits</h3>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-1">
            <div className="rounded-2xl border-2 border-green-700 p-4 text-center bg-white">
              <div className="mx-auto w-20 h-20 rounded-full border-2 border-green-700 flex items-center justify-center mb-3">
                <Scale className="w-10 h-10 text-green-700"/>
              </div>
              <div className="uppercase tracking-wide text-xs text-green-700 font-semibold">State of Connecticut</div>
              <div className="text-sm text-green-800">Public Utilities Regulatory Authority</div>
            </div>
          </div>
          <div className="md:col-span-2 space-y-4">
            <div>
              <div className="font-semibold text-green-800 flex items-center gap-2"><FileText className="w-4 h-4"/> Renewable Portfolio Standard (RPS)</div>
              <p className="text-sm text-green-900 mt-1">CT law requires utilities to procure a portion of electricity from renewables. The current schedule targets <span className="font-semibold">~30% Class I renewables in 2025</span>, with additional Class II/III requirements. Policies expand clean energy and reduce exposure to fuel price spikes.</p>
            </div>
            <div>
              <div className="font-semibold text-green-800 flex items-center gap-2"><FileText className="w-4 h-4"/> Public Benefits on Your Bill</div>
              <ul className="text-sm text-green-900 list-disc pl-5 space-y-1 mt-1">
                <li><span className="font-medium">What it is:</span> per‑kWh charges that fund state‑authorized programs—efficiency, renewable purchases, low‑income assistance, and incentives.</li>
                <li><span className="font-medium">How it shows:</span> often listed as <span className="font-semibold">Combined Public Benefits</span>, plus related items like <span className="font-semibold">FMCC</span> or <span className="font-semibold">Decoupling</span>.</li>
                <li><span className="font-medium">Who benefits:</span> CT residents & businesses via weatherization, rebates, and renewable investment support.</li>
                <li><span className="font-medium">Profit:</span> utilities <span className="font-semibold">do not profit</span> on these pass‑throughs; they’re overseen by regulators.</li>
              </ul>
            </div>
            <div className="flex gap-2">
              <Button onClick={()=>setOpen(true)} className="bg-green-600 text-white border-green-700 hover:bg-green-700">Learn more</Button>
              <Button onClick={()=>setShowBills(true)} className="bg-white text-green-900">See sample bills</Button>
            </div>
            <div className="text-xs text-green-700">Labels and rates change—always check your latest bill.</div>
          </div>
        </div>
        <Modal open={open} onClose={()=>setOpen(false)} title="CT Mandates: Sources & Overview">
          <ul className="list-disc pl-5 space-y-1">
            <li><a className="text-green-800 underline" href={CONFIG.SOURCES.PURA_RPS} target="_blank" rel="noreferrer">CT Renewable Portfolio Standard (PURA)</a></li>
            <li><a className="text-green-800 underline" href={CONFIG.SOURCES.PURA_FAQ_PDF} target="_blank" rel="noreferrer">PURA FAQ: Public Benefits & FMCC (PDF)</a></li>
            <li><a className="text-green-800 underline" href={CONFIG.SOURCES.OCC_PUBLIC_BENEFITS} target="_blank" rel="noreferrer">Office of Consumer Counsel: Public Benefits</a></li>
            <li><a className="text-green-800 underline" href={CONFIG.SOURCES.ENERGIZE_DASHBOARD} target="_blank" rel="noreferrer">EnergizeCT: Funding & Programs</a></li>
            <li><a className="text-green-800 underline" href={CONFIG.SOURCES.UI_SAMPLE_BILL} target="_blank" rel="noreferrer">UI Sample Bill (where charges appear)</a></li>
          </ul>
          <div className="mt-3 text-xs text-green-700">Official sources open in a new tab. Labels and rates change—always check your latest bill.</div>
        </Modal>
        <Modal open={showBills} onClose={()=>setShowBills(false)} title="Where to find it on the bill (Redacted)">
          <div className="grid sm:grid-cols-2 gap-4">
            <AnnotatedBill title="United Illuminating" template="ui" defaultSrcs={["/bills/bill1.jpg","/bills/bill2.jpg"]}/>
            <AnnotatedBill title="Eversource" template="eversource" defaultSrcs={["/bills/bill3.jpg","/bills/bill4.jpg"]}/>
          </div>
        </Modal>
      </CardContent>
    </Card>
  );
}

// ========= SCHEDULING (Email-only)
function ScheduleRequest({ open, onClose }){
  const [name,setName]=useState("");
  const [email,setEmail]=useState("");
  const [phone,setPhone]=useState("");
  const [date,setDate]=useState("");
  const [time,setTime]=useState("");
  const [notes,setNotes]=useState("");
  const [status,setStatus]=useState("idle");

  const submit=async()=>{
    if(!CONFIG.LEAD_WEBHOOK_URL){ setStatus("nohook"); return; }
    setStatus("loading");
    try{
      const res=await fetch(CONFIG.LEAD_WEBHOOK_URL,{
        method:"POST",
        headers:{"Content-Type":"application/json","Accept":"application/json"},
        body:JSON.stringify({ type:"schedule", name,email,phone, preferred_date:date, preferred_time:time, notes, source:"GreenMachineApp", subject:`Schedule request - ${name || 'Prospect'} (The Green Machine)` })
      });
      if(!res.ok) throw new Error("bad");
      setStatus("ok");
      setName("");setEmail("");setPhone("");setDate("");setTime("");setNotes("");
    }catch(e){ setStatus("error"); }
  };

  return (
    <Modal open={open} onClose={onClose} title="Request a Meeting (Email)">
      <div className="grid sm:grid-cols-2 gap-3">
        <div><Label>Name</Label><Input value={name} onChange={e=>setName(e.target.value)} placeholder="Jane Homeowner"/></div>
        <div><Label>Email</Label><Input value={email} onChange={e=>setEmail(e.target.value)} placeholder="name@email.com"/></div>
        <div><Label>Phone</Label><Input value={phone} onChange={e=>setPhone(e.target.value)} placeholder="(203) 555-0123"/></div>
        <div><Label>Preferred Date</Label><Input type="date" value={date} onChange={e=>setDate(e.target.value)}/></div>
        <div><Label>Preferred Time</Label><Input type="time" value={time} onChange={e=>setTime(e.target.value)}/></div>
        <div className="sm:col-span-2"><Label>Notes</Label><Input value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Roof age, utility, any questions…"/></div>
      </div>
      <div className="mt-3 flex gap-2">
        <Button onClick={submit} className="bg-green-600 text-white border-green-700 hover:bg-green-700">Send Request</Button>
        <a href={`sms:${CONFIG.CONTACT_PHONE}?body=Hi%20Green%20Machine%2C%20I%27d%20like%20to%20book%20a%20consult.`} className="px-4 py-2 rounded-2xl border border-green-400">Text Instead</a>
      </div>
      {status==="ok" && <div className="mt-2 text-sm text-green-700">Request sent! We’ll confirm by email/text.</div>}
      {status==="loading" && <div className="mt-2 text-sm text-green-700">Sending…</div>}
      {status==="error" && <div className="mt-2 text-sm text-red-700">Something went wrong. Please try again or text us.</div>}
      {status==="nohook" && <div className="mt-2 text-sm text-orange-700">No email endpoint configured yet. Add one to CONFIG.LEAD_WEBHOOK_URL.</div>}
    </Modal>
  );
}

// ========= Lead capture
function LeadCapture(){
  const [name,setName]=useState("");
  const [address,setAddress]=useState("");
  const [email,setEmail]=useState("");
  const [phone,setPhone]=useState("");
  const [utility,setUtility]=useState("Eversource");
  const [status,setStatus]=useState("idle");

  const submit=async()=>{
    if(!CONFIG.LEAD_WEBHOOK_URL){ setStatus("nohook"); return; }
    setStatus("loading");
    try{
      const res=await fetch(CONFIG.LEAD_WEBHOOK_URL,{
        method:"POST",
        headers:{"Content-Type":"application/json","Accept":"application/json"},
        body:JSON.stringify({ type:"lead", name,address,email,phone,utility, source:"GreenMachineApp", subject:`Lead - ${name || 'Prospect'} (The Green Machine)` })
      });
      if(!res.ok) throw new Error("bad");
      setStatus("ok");
      setName("");setAddress("");setEmail("");setPhone("");
    }catch(e){ setStatus("error"); }
  };

  return (
    <Card>
      <CardHeader>
        <Building2 className="w-5 h-5 text-green-700"/>
        <h3 className="font-semibold text-green-800">Free Solar Assessment</h3>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-2 gap-3">
          <div><Label>Name</Label><Input value={name} onChange={e=>setName(e.target.value)} placeholder="Jane Homeowner"/></div>
          <div><Label>Phone</Label><Input value={phone} onChange={e=>setPhone(e.target.value)} placeholder="(203) 555-0123"/></div>
          <div className="md:col-span-2"><Label>Address</Label><Input value={address} onChange={e=>setAddress(e.target.value)} placeholder="123 Maple Ave, New Haven, CT"/></div>
          <div><Label>Email</Label><Input value={email} onChange={e=>setEmail(e.target.value)} placeholder="name@email.com"/></div>
          <div><Label>Utility</Label>\n            <select className="w-full px-3 py-2 rounded-xl border border-green-300" value={utility} onChange={e=>setUtility(e.target.value)}>\n              <option>Eversource</option>\n              <option>UI</option>\n              <option>Other</option>\n            </select></div>
        </div>
        <div className="mt-3 flex gap-2">
          <Button onClick={submit} className="bg-green-600 text-white border-green-700 hover:bg-green-700">Request My Assessment</Button>
          <a href={`sms:${CONFIG.CONTACT_PHONE}?body=Hi%20Green%20Machine%2C%20I%27d%20like%20a%20free%20solar%20assessment.`} className="px-4 py-2 rounded-2xl border border-green-400">Text Us</a>
        </div>
        {status==="ok" && <div className="mt-2 text-sm text-green-700">Thanks! We received your request and will reach out shortly.</div>}
        {status==="loading" && <div className="mt-2 text-sm text-green-700">Submitting…</div>}
        {status==="error" && <div className="mt-2 text-sm text-red-700">Something went wrong. Please text us if urgent.</div>}
        {status==="nohook" && <div className="mt-2 text-sm text-orange-700">No email endpoint configured yet. Add one to CONFIG.LEAD_WEBHOOK_URL.</div>}
      </CardContent>
    </Card>
  );
}

// ========= Savings Estimator
function SavingsEstimator() {
  const [bill, setBill] = useState(180);
  const [gridInflation, setGridInflation] = useState(0.06);
  const [ppaRate, setPpaRate] = useState(0.179);
  const [usageKWh, setUsageKWh] = useState(750);
  const years = 25;

  const { gridLifetime, ppaLifetime, monthlyPpaEst } = useMemo(() => {
    let total = 0; let monthly = bill;
    for (let y = 0; y < years; y++) { total += monthly * 12; monthly *= 1 + gridInflation; }
    const monthlyPpa = usageKWh * ppaRate; const ppaTotal = monthlyPpa * 12 * years;
    return { gridLifetime: total, ppaLifetime: ppaTotal, monthlyPpaEst: monthlyPpa };
  }, [bill, gridInflation, ppaRate, usageKWh]);
  const savings = Math.max(0, gridLifetime - ppaLifetime);

  return (
    <Card>
      <CardHeader><LineChart className="w-5 h-5 text-green-700"/><h3 className="font-semibold text-green-800">Savings Estimator</h3></CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-3">
            <div><Label>Average monthly bill ($)</Label><Input type="number" value={bill} onChange={(e)=>setBill(Number(e.target.value||0))}/></div>
            <div><Label>Monthly usage (kWh)</Label><Input type="number" value={usageKWh} onChange={(e)=>setUsageKWh(Number(e.target.value||0))}/></div>
            <div><Label>Grid price growth (%)</Label><Input type="number" value={(gridInflation*100).toFixed(1)} onChange={(e)=>setGridInflation(Number(e.target.value||0)/100)}/></div>
            <div><Label>PPA rate ($/kWh)</Label><Input type="number" step="0.001" value={ppaRate} onChange={(e)=>setPpaRate(Number(e.target.value||0))}/></div>
          </div>
          <div className="space-y-3">
            <Card className="bg-green-50 border-green-200">
              <CardContent>
                <div className="text-xs text-green-700">Lifetime Grid Cost</div>
                <div className="text-xl font-semibold text-green-900">{currency(gridLifetime)}</div>
                <div className="text-xs text-green-700">vs Solar PPA: {currency(ppaLifetime)}</div>
                <div className="text-xl font-bold text-green-800 mt-1">Savings: {currency(savings)}</div>
                <div className="text-xs text-green-700 mt-2">Est. monthly PPA bill: {currency(monthlyPpaEst)}</div>
              </CardContent>
            </Card>
          </div>
        </div>
        <div className="text-xs text-green-700 mt-2">* Quick estimate. Actual savings depend on roof, shading, utility rates, and program terms.</div>
      </CardContent>
    </Card>
  );
}

// ========= Events, News, Contact, Leaderboard (trimmed for brevity)
function EventsFeed(){ return (
  <Card>
    <CardHeader><Calendar className="w-5 h-5 text-green-700"/><h3 className="font-semibold text-green-800">Local Events</h3></CardHeader>
    <CardContent>
      <div className="space-y-3">
        {demoEvents.map(e => (
          <div key={e.id} className="flex items-start gap-3 p-3 rounded-xl border border-green-200">
            <div className="text-green-800 font-semibold w-32">{e.date}<div className="text-xs text-green-700">{e.time}</div></div>
            <div>
              <div className="font-medium text-green-900">{e.title}</div>
              <div className="text-sm text-green-800 flex items-center gap-1"><MapPin className="w-4 h-4" /> {e.where}</div>
              <div className="text-sm text-green-900 mt-1">{e.desc}</div>
            </div>
          </div>
        ))}
      </div>
    </CardContent>
  </Card>
);}

function NewsBrief(){ return (
  <Card>
    <CardHeader><Newspaper className="w-5 h-5 text-green-700"/><h3 className="font-semibold text-green-800">Energy Briefs</h3></CardHeader>
    <CardContent>
      <div className="space-y-2">
        {demoNews.map(n => (
          <div key={n.id} className="flex items-center justify-between p-3 rounded-xl border border-green-200">
            <div>
              <div className="font-medium text-green-900">{n.headline}</div>
              <div className="text-xs text-green-700">{n.source} • {n.time}</div>
            </div>
            <Button className="text-green-800">Read</Button>
          </div>
        ))}
      </div>
    </CardContent>
  </Card>
);}

function Leaderboard(){ return (
  <Card>
    <CardHeader><Users className="w-5 h-5 text-green-700"/><h3 className="font-semibold text-green-800">Community Leaderboard</h3></CardHeader>
    <CardContent>
      <div className="grid grid-cols-3 gap-3">
        {demoLeaders.map((r,i)=>(
          <div key={r.name} className="p-3 rounded-xl border border-green-200 text-center">
            <div className="text-xs text-green-700">#{i+1}</div>
            <div className="font-semibold text-green-900">{r.name}</div>
            <div className="text-green-800 font-bold">{r.points} pts</div>
          </div>
        ))}
      </div>
    </CardContent>
  </Card>
);}

function ContactBlock(){
  const [openSchedule,setOpenSchedule]=useState(false);
  return (
    <Card>
      <CardHeader><Phone className="w-5 h-5 text-green-700"/><h3 className="font-semibold text-green-800">Talk to The Green Machine</h3></CardHeader>
      <CardContent>
        <div className="text-sm text-green-900 mb-2">Got questions about solar, PPAs, or saving on your bill? Reach out below.</div>
        <div className="flex gap-2 flex-wrap">
          <a href={`sms:${CONFIG.CONTACT_PHONE}?body=Hi%20Green%20Machine%2C%20I%27d%20like%20to%20book%20a%20consult.`} className="px-4 py-2 rounded-2xl border border-green-400">Text Us</a>
          <a href={`tel:${CONFIG.CONTACT_PHONE}`} className="px-4 py-2 rounded-2xl border border-green-400">Call Now</a>
          <Button onClick={()=>setOpenSchedule(true)} className="bg-yellow-400 text-green-900 border-yellow-500 hover:bg-yellow-500 flex items-center gap-1"><Clock className="w-4 h-4"/> Request by Email</Button>
        </div>
        <ScheduleRequest open={openSchedule} onClose={()=>setOpenSchedule(false)}/>
      </CardContent>
    </Card>
  );
}

// ========= App
export default function App(){
  const [tab,setTab]=useState("home");
  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-yellow-50 text-green-900">
      <header className="sticky top-0 bg-white/80 backdrop-blur border-b border-green-200">
        <div className="max-w-6xl mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <motion.div initial={{rotate:-20,opacity:0}} animate={{rotate:0,opacity:1}} transition={{type:"spring"}} className="p-2 rounded-2xl bg-green-100"><LogoMark/></motion.div>
            <div className="font-bold text-lg text-green-800">The Green Machine</div>
            <div className="hidden md:block text-xs text-green-700 ml-2">Power your home. Power your wallet.</div>
          </div>
          <nav className="flex gap-1">{
            [
              {key:"home",label:"Home",icon:Leaf},
              {key:"savings",label:"Savings",icon:Wallet},
              {key:"analyzer",label:"Bill",icon:Info},
              {key:"events",label:"Events",icon:Calendar},
              {key:"news",label:"News",icon:Newspaper},
              {key:"ct",label:"CT Mandate",icon:ShieldCheck}
            ].map(({key,label,icon:Icon})=> (
              <Button key={key} onClick={()=>setTab(key)} className={`bg-white ${tab===key?"ring-2 ring-green-300":""}`}><Icon className="w-4 h-4 mr-1"/>{label}</Button>
            ))
          }</nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6 space-y-6">
        {tab==="home" && (
          <>
            <Card>
              <CardHeader><Building2 className="w-5 h-5 text-green-700"/><h3 className="font-semibold text-green-800">Welcome to The Green Machine Hub</h3></CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 text-sm text-green-900 space-y-1">
                  <li>Decode your utility bill and uncover the CT charges funding clean energy.</li>
                  <li>Estimate your solar savings with live tools.</li>
                  <li>Request a consult or refer neighbors—community wins.</li>
                </ul>
              </CardContent>
            </Card>
            <LeadCapture/>
            <SavingsEstimator/>
            <CTMandate/>
            <EventsFeed/>
            <Leaderboard/>
            <NewsBrief/>
          </>
        )}

        {tab==="savings" && <SavingsEstimator/>}
        {tab==="analyzer" && <BillDecoder/>}
        {tab==="ct" && <CTMandate/>}

        <ContactBlock/>
      </main>

      
      <footer className="py-10 text-center text-xs text-green-800">
        © {new Date().getFullYear()} The Green Machine • Clean Energy for Connecticut
        <div className="mt-2 space-x-4">
          <a className="underline" href="/privacy">Privacy</a>
          <a className="underline" href="/terms">Terms</a>
        </div>
      </footer>
    
    </div>
  );
}
